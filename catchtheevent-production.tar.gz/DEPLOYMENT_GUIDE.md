# 🚀 Catch The Event - Production Deployment Guide

## Quick VPS Deployment on Hostinger

### Prerequisites
- Hostinger VPS with Ubuntu 20.04+ or CentOS 8+
- Root access to the server
- Domain name pointed to your VPS IP

### 1. Server Setup

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2 globally
sudo npm install -g pm2

# Install Nginx
sudo apt install nginx -y

# Install Certbot for SSL
sudo apt install certbot python3-certbot-nginx -y
```

### 2. Upload Your Code

```bash
# Create app directory
sudo mkdir -p /var/www/catchtheevent
sudo chown -R $USER:$USER /var/www/catchtheevent

# Upload your project files to /var/www/catchtheevent
# You can use SCP, SFTP, or Git clone
```

### 3. Environment Setup

```bash
# Copy environment variables
cp env.production.example .env.local

# Edit with your actual values
nano .env.local
```

### 4. Install Dependencies & Build

```bash
cd /var/www/catchtheevent
npm ci --production
npm run build
```

### 5. Configure Nginx

```bash
# Copy Nginx configuration
sudo cp nginx.conf /etc/nginx/sites-available/catchtheevent.com
sudo ln -s /etc/nginx/sites-available/catchtheevent.com /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default

# Test Nginx configuration
sudo nginx -t
```

### 6. Setup SSL Certificate

```bash
# Get SSL certificate
sudo certbot --nginx -d catchtheevent.com -d www.catchtheevent.com

# Auto-renewal
sudo crontab -e
# Add: 0 12 * * * /usr/bin/certbot renew --quiet
```

### 7. Deploy Application

```bash
# Make deployment script executable
chmod +x deploy.sh

# Run deployment
sudo ./deploy.sh
```

### 8. Verify Deployment

- Visit: https://catchtheevent.com
- Check PM2 status: `pm2 status`
- Check Nginx status: `sudo systemctl status nginx`
- View logs: `pm2 logs catchtheevent`

## Environment Variables Required

Update `.env.local` with your actual values:

```bash
# Database
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key

# Stripe
STRIPE_PUBLISHABLE_KEY=your_stripe_publishable_key
STRIPE_SECRET_KEY=your_stripe_secret_key

# Email
SENDGRID_API_KEY=your_sendgrid_api_key

# Security
NEXTAUTH_SECRET=your_random_secret_key
```

## Quick Commands

```bash
# Restart application
pm2 restart catchtheevent

# View logs
pm2 logs catchtheevent

# Monitor
pm2 monit

# Update deployment
sudo ./deploy.sh
```

## Troubleshooting

### Application not starting
```bash
pm2 logs catchtheevent
sudo systemctl status nginx
```

### SSL issues
```bash
sudo certbot certificates
sudo certbot renew --dry-run
```

### Permission issues
```bash
sudo chown -R www-data:www-data /var/www/catchtheevent
sudo chmod -R 755 /var/www/catchtheevent
```

## Performance Optimization

- Enable Gzip compression (already configured)
- Set up Redis for caching (optional)
- Configure CDN for static assets
- Monitor with PM2 monitoring

## Security Checklist

- ✅ SSL/HTTPS enabled
- ✅ Security headers configured
- ✅ Rate limiting enabled
- ✅ Firewall configured
- ✅ Regular backups
- ✅ Auto-updates enabled

Your Catch The Event website is now production-ready! 🎉
