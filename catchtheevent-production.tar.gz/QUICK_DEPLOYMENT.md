# ⚡ QUICK DEPLOYMENT - Catch The Event

## 🚀 5-Minute VPS Deployment

### Step 1: Upload Files
```bash
# Upload all files to your VPS at /var/www/catchtheevent
```

### Step 2: Server Setup (Run on VPS)
```bash
# Install Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2 & Nginx
sudo npm install -g pm2
sudo apt install nginx certbot python3-certbot-nginx -y
```

### Step 3: Environment Setup
```bash
cd /var/www/catchtheevent
cp env.production.example .env.local
nano .env.local  # Add your actual values
```

### Step 4: Deploy
```bash
chmod +x deploy.sh
sudo ./deploy.sh
```

### Step 5: SSL Certificate
```bash
sudo certbot --nginx -d catchtheevent.com -d www.catchtheevent.com
```

## ✅ DONE! Your site is live at https://catchtheevent.com

## 🔧 Quick Commands
```bash
pm2 restart catchtheevent    # Restart app
pm2 logs catchtheevent       # View logs
sudo systemctl reload nginx  # Reload Nginx
```

## 📋 Required Environment Variables
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `STRIPE_PUBLISHABLE_KEY`
- `STRIPE_SECRET_KEY`
- `SENDGRID_API_KEY`
- `NEXTAUTH_SECRET`

That's it! 🎉
