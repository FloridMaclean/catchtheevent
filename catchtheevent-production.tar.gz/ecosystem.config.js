module.exports = {
  apps: [{
    name: 'catchtheevent',
    script: 'npm',
    args: 'start',
    cwd: '/var/www/catchtheevent',
    instances: 'max',
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: '/var/log/pm2/catchtheevent-error.log',
    out_file: '/var/log/pm2/catchtheevent-out.log',
    log_file: '/var/log/pm2/catchtheevent-combined.log',
    time: true,
    max_memory_restart: '1G',
    node_args: '--max-old-space-size=1024'
  }]
}
