#!/bin/bash

# Catch The Event - Production Deployment Script
# For Hostinger VPS

set -e

echo "🚀 Starting Catch The Event Production Deployment..."

# Configuration
APP_NAME="catchtheevent"
APP_DIR="/var/www/catchtheevent"
BACKUP_DIR="/var/backups/catchtheevent"
LOG_FILE="/var/log/deploy.log"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Logging function
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1" | tee -a $LOG_FILE
}

error() {
    echo -e "${RED}[ERROR]${NC} $1" | tee -a $LOG_FILE
    exit 1
}

warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1" | tee -a $LOG_FILE
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    error "Please run as root (use sudo)"
fi

# Create directories if they don't exist
log "Creating directories..."
mkdir -p $APP_DIR
mkdir -p $BACKUP_DIR
mkdir -p /var/log/pm2

# Backup current deployment
if [ -d "$APP_DIR" ] && [ "$(ls -A $APP_DIR)" ]; then
    log "Creating backup of current deployment..."
    BACKUP_NAME="backup-$(date +%Y%m%d-%H%M%S)"
    tar -czf "$BACKUP_DIR/$BACKUP_NAME.tar.gz" -C $APP_DIR .
    log "Backup created: $BACKUP_DIR/$BACKUP_NAME.tar.gz"
fi

# Stop PM2 processes
log "Stopping PM2 processes..."
pm2 stop $APP_NAME 2>/dev/null || true
pm2 delete $APP_NAME 2>/dev/null || true

# Navigate to app directory
cd $APP_DIR

# Pull latest code (if using git)
if [ -d ".git" ]; then
    log "Pulling latest code from repository..."
    git pull origin main
else
    log "No git repository found. Please upload your code manually."
fi

# Install dependencies
log "Installing dependencies..."
npm ci --production

# Build the application
log "Building application..."
npm run build

# Set proper permissions
log "Setting permissions..."
chown -R www-data:www-data $APP_DIR
chmod -R 755 $APP_DIR

# Start PM2 process
log "Starting application with PM2..."
pm2 start ecosystem.config.js

# Save PM2 configuration
pm2 save
pm2 startup

# Reload Nginx
log "Reloading Nginx..."
nginx -t && systemctl reload nginx

# Health check
log "Performing health check..."
sleep 5
if curl -f http://localhost:3000 > /dev/null 2>&1; then
    log "✅ Application is running successfully!"
else
    error "❌ Application health check failed!"
fi

# Show status
log "Deployment completed successfully!"
log "Application status:"
pm2 status

log "🎉 Catch The Event is now live!"
log "Visit: https://catchtheevent.com"
